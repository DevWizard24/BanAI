
import React from 'react';
import { StylePreset } from '../types';

interface StylePresetButtonProps {
  style: StylePreset;
  onClick: () => void;
}

export const StylePresetButton: React.FC<StylePresetButtonProps> = ({ style, onClick }) => {
  return (
    <button
      onClick={onClick}
      className="text-left text-sm p-2 bg-banana-dark hover:bg-banana-dark/50 border border-banana-surface rounded-lg transition-all duration-200 group"
      title={`Add style: ${style.prompt}`}
    >
      <div className="flex items-center space-x-2">
        <span className="text-lg transition-transform duration-200 group-hover:scale-125">{style.emoji}</span>
        <span className="font-medium text-banana-light/90">{style.name}</span>
      </div>
    </button>
  );
};
