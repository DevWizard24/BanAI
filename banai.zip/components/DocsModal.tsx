import React, { useState } from 'react';
import { FAQ_DATA, ABOUT_DATA, CONTACT_DATA, DISCLAIMER_DATA, PRIVACY_POLICY_DATA, MONETIZATION_DATA } from '../constants';
import { Icon } from './Icon';

interface DocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Tab = 'faq' | 'about' | 'monetization' | 'contact' | 'disclaimer' | 'privacy';

export const DocsModal: React.FC<DocsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<Tab>('faq');
  
  if (!isOpen) return null;

  const renderContent = () => {
    switch(activeTab) {
      case 'faq':
        return (
          <div className="space-y-4">
            {FAQ_DATA.map((faq, index) => (
              <details key={index} className="bg-banana-dark p-4 rounded-lg group">
                <summary className="font-semibold text-banana-light cursor-pointer list-none flex justify-between items-center">
                  {faq.question}
                  <span className="text-banana-yellow transition-transform duration-300 transform group-open:rotate-180">
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <p className="text-banana-light/80 mt-3 text-sm leading-relaxed whitespace-pre-line">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>
        );
      case 'about':
        return <div className="text-banana-light/80 leading-relaxed whitespace-pre-line">{ABOUT_DATA.content}</div>
      case 'monetization':
        return <div className="text-banana-light/80 leading-relaxed whitespace-pre-line">{MONETIZATION_DATA.content}</div>
      case 'contact':
        return <div className="text-banana-light/80 leading-relaxed whitespace-pre-line">{CONTACT_DATA.content}</div>
      case 'disclaimer':
        return <div className="text-banana-light/80 leading-relaxed whitespace-pre-line">{DISCLAIMER_DATA.content}</div>
      case 'privacy':
        return <div className="text-banana-light/80 leading-relaxed whitespace-pre-line">{PRIVACY_POLICY_DATA.content}</div>
      default:
        return null;
    }
  };

  const getTabTitle = () => {
    switch(activeTab) {
        case 'faq': return 'Frequently Asked Questions';
        case 'about': return ABOUT_DATA.title;
        case 'monetization': return MONETIZATION_DATA.title;
        case 'contact': return CONTACT_DATA.title;
        case 'disclaimer': return DISCLAIMER_DATA.title;
        case 'privacy': return PRIVACY_POLICY_DATA.title;
    }
  }

  const TabButton: React.FC<{tab: Tab, icon: React.ComponentProps<typeof Icon>['type'], label: string}> = ({ tab, icon, label }) => {
    const isActive = activeTab === tab;
    return (
        <button
            onClick={() => setActiveTab(tab)}
            className={`flex flex-col items-center justify-center space-y-1 p-3 w-full rounded-lg transition-colors duration-200 ${isActive ? 'bg-banana-yellow/10 text-banana-yellow' : 'text-banana-light/60 hover:bg-banana-dark hover:text-banana-light'}`}
            aria-current={isActive ? 'page' : undefined}
        >
            <Icon type={icon} className="h-6 w-6" />
            <span className="text-xs font-medium">{label}</span>
        </button>
    );
  }

  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-banana-surface rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col md:flex-row overflow-hidden"
        onClick={e => e.stopPropagation()} // Prevent click from closing modal
      >
        <aside className="w-full md:w-48 bg-banana-dark/30 p-4 border-b md:border-b-0 md:border-r border-banana-dark flex md:flex-col justify-start space-x-2 md:space-x-0 md:space-y-2">
            <TabButton tab="faq" icon="help" label="FAQ" />
            <TabButton tab="about" icon="info" label="About" />
            <TabButton tab="monetization" icon="money" label="Monetization" />
            <TabButton tab="contact" icon="mail" label="Contact" />
            <TabButton tab="disclaimer" icon="warning" label="Disclaimer" />
            <TabButton tab="privacy" icon="shield" label="Privacy" />
        </aside>

        <div className="flex-1 flex flex-col">
            <header className="flex items-center justify-between p-4 border-b border-banana-dark">
              <h2 className="text-xl font-bold text-banana-yellow">{getTabTitle()}</h2>
              <button onClick={onClose} className="text-banana-light/70 hover:text-banana-light transition-colors" aria-label="Close Docs">
                <Icon type="close" />
              </button>
            </header>
            
            <main className="p-6 overflow-y-auto">
              {renderContent()}
            </main>
        </div>
      </div>
    </div>
  );
};
