
import React from 'react';

interface HeaderProps {
  currentView: 'studio' | 'gallery';
  onNavigate: (view: 'studio' | 'gallery') => void;
  onOpenDocs: () => void;
}


export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, onOpenDocs }) => {
  const navItemClasses = "px-4 py-2 rounded-md text-sm font-medium transition-colors";
  const activeClasses = "bg-banana-yellow text-banana-dark";
  const inactiveClasses = "text-banana-light/70 hover:bg-banana-surface hover:text-banana-light";

  return (
    <header className="bg-banana-surface/80 backdrop-blur-sm sticky top-0 z-10 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <span className="text-4xl">🤖</span>
          <h1 className="text-2xl font-bold text-banana-yellow tracking-tight">
            BanAI
          </h1>
        </div>
        <nav className="flex space-x-2 bg-banana-dark p-1 rounded-lg">
          <button onClick={() => onNavigate('studio')} className={`${navItemClasses} ${currentView === 'studio' ? activeClasses : inactiveClasses}`}>
            Studio
          </button>
          <button onClick={() => onNavigate('gallery')} className={`${navItemClasses} ${currentView === 'gallery' ? activeClasses : inactiveClasses}`}>
            Gallery
          </button>
           <button onClick={onOpenDocs} className={`${navItemClasses} ${inactiveClasses}`}>
            Docs
          </button>
        </nav>
      </div>
    </header>
  );
};