
import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';

interface ImageDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
  isUpscaling: boolean;
  error: string | null;
  prompt: string;
  onShare: (prompt: string, imageUrl: string) => void;
  onUpscale: () => void;
  onHistoryBack: () => void;
  onHistoryForward: () => void;
  canGoBack: boolean;
  canGoForward: boolean;
}

const ZoomableImageModal: React.FC<{ imageUrl: string; alt: string; onClose: () => void; }> = ({ imageUrl, alt, onClose }) => (
  <div
    className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-scale"
    onClick={onClose}
    aria-modal="true"
    role="dialog"
  >
    <img
      src={imageUrl}
      alt={`Zoomed view of ${alt}`}
      className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
      onClick={(e) => e.stopPropagation()} // Prevent closing modal when clicking image
    />
    <button
      onClick={onClose}
      className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors"
      aria-label="Close zoomed image view"
    >
      <Icon type="close" className="h-8 w-8" />
    </button>
  </div>
);


export const ImageDisplay: React.FC<ImageDisplayProps> = ({ 
  imageUrl, 
  isLoading, 
  isUpscaling, 
  error, 
  prompt, 
  onShare, 
  onUpscale,
  onHistoryBack,
  onHistoryForward,
  canGoBack,
  canGoForward,
}) => {
  const [isShared, setIsShared] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  // Reset shared status when a new image is generated or loading starts
  useEffect(() => {
    if (isLoading || !imageUrl) {
      setIsShared(false);
    }
  }, [isLoading, imageUrl]);

  const downloadImage = () => {
    if (!imageUrl) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    // Create a filename from the prompt
    const filename = prompt.substring(0, 30).replace(/[^a-zA-Z0-9]/g, '_') + '.png';
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = () => {
    if (imageUrl && prompt) {
      onShare(prompt, imageUrl);
      setIsShared(true);
    }
  };

  return (
    <>
      {isZoomed && imageUrl && <ZoomableImageModal imageUrl={imageUrl} alt={prompt} onClose={() => setIsZoomed(false)} />}
      <div className="w-full aspect-square bg-banana-surface rounded-2xl shadow-lg flex items-center justify-center p-4 relative overflow-hidden">
        {isLoading && (
          <div className="text-center space-y-4 text-banana-yellow">
            <Icon type="loader" className="h-16 w-16 mx-auto animate-spin" />
            <p className="font-semibold text-lg">Unleashing your creativity...</p>
            <p className="text-sm text-banana-light/70">The AI is working its magic!</p>
          </div>
        )}

        {error && !isLoading && (
          <div className="text-center space-y-4 text-red-400 p-8">
            <Icon type="error" className="h-16 w-16 mx-auto" />
            <p className="font-semibold text-lg">Oops! Something went wrong.</p>
            <p className="text-sm text-red-300/80">{error}</p>
          </div>
        )}

        {!isLoading && !error && imageUrl && (
          <>
            <img
              src={imageUrl}
              alt={prompt}
              className="w-full h-full object-contain rounded-lg cursor-zoom-in animate-fade-in-scale"
              onClick={() => setIsZoomed(true)}
            />
            {isUpscaling && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center text-center space-y-4 text-banana-yellow z-10 transition-opacity duration-300">
                <Icon type="loader" className="h-12 w-12 mx-auto animate-spin" />
                <p className="font-semibold text-lg">Upscaling to HD...</p>
              </div>
            )}
            
            {/* History Controls */}
            <div className="absolute bottom-4 left-4 flex space-x-2 items-center">
              <button
                onClick={onHistoryBack}
                disabled={!canGoBack || isUpscaling || isLoading}
                className="bg-banana-dark/70 text-banana-yellow backdrop-blur-sm p-3 rounded-full hover:bg-banana-dark transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Previous Image"
              >
                <Icon type="arrow-left" />
              </button>
              <button
                onClick={onHistoryForward}
                disabled={!canGoForward || isUpscaling || isLoading}
                className="bg-banana-dark/70 text-banana-yellow backdrop-blur-sm p-3 rounded-full hover:bg-banana-dark transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Next Image"
              >
                <Icon type="arrow-right" />
              </button>
            </div>
            
            {/* Action Controls */}
            <div className="absolute bottom-4 right-4 flex space-x-2 items-center">
              <button
                onClick={handleShare}
                disabled={isShared || isUpscaling}
                className={`flex items-center space-x-2 backdrop-blur-sm py-2 px-4 rounded-lg transition-colors duration-300 text-sm font-semibold ${
                  isShared
                    ? 'bg-green-500 text-white'
                    : 'bg-banana-dark/70 text-banana-yellow hover:bg-banana-dark'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
                title={isShared ? "Shared to Gallery" : "Share to Gallery"}
              >
                {isShared ? (
                  <>
                    <Icon type="check" className="h-5 w-5" />
                    <span>Shared</span>
                  </>
                ) : (
                  <>
                    <Icon type="share" className="h-5 w-5" />
                    <span>Share to Gallery</span>
                  </>
                )}
              </button>
              <button
                onClick={() => setIsZoomed(true)}
                disabled={isUpscaling || isLoading}
                className="bg-banana-dark/70 text-banana-yellow backdrop-blur-sm p-3 rounded-full hover:bg-banana-dark transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Zoom In"
              >
                <Icon type="zoom-in" />
              </button>
              <button
                onClick={onUpscale}
                disabled={isUpscaling || isLoading}
                className="bg-banana-dark/70 text-banana-yellow backdrop-blur-sm p-3 rounded-full hover:bg-banana-dark transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                title="HD Upscale"
              >
                <Icon type="upscale" />
              </button>
              <button
                onClick={downloadImage}
                disabled={isUpscaling}
                className="bg-banana-dark/70 text-banana-yellow backdrop-blur-sm p-3 rounded-full hover:bg-banana-dark transition-all duration-300 disabled:opacity-50"
                title="Download Image"
              >
                <Icon type="download" />
              </button>
            </div>
          </>
        )}

        {!isLoading && !error && !imageUrl && (
          <div className="text-center space-y-4 text-banana-light/50">
            <Icon type="placeholder" className="h-24 w-24 mx-auto" />
            <p className="font-semibold text-lg">Your masterpiece will appear here</p>
            <p className="text-sm">Enter a prompt and click "Generate Image"</p>
          </div>
        )}
      </div>
    </>
  );
};
