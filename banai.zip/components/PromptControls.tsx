
import React from 'react';
import { StylePreset } from '../types';
import { StylePresetButton } from './StylePresetButton';
import { Icon } from './Icon';

interface PromptControlsProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  stylePresets: StylePreset[];
  onStyleSelect: (style: StylePreset) => void;
  onGenerate: () => void;
  onEnhance: () => void;
  isLoading: boolean;
  isEnhancing: boolean;
  isTransparent: boolean;
  setIsTransparent: (isTransparent: boolean) => void;
  aspectRatio: string;
  setAspectRatio: (ratio: string) => void;
}

export const PromptControls: React.FC<PromptControlsProps> = ({
  prompt,
  setPrompt,
  stylePresets,
  onStyleSelect,
  onGenerate,
  onEnhance,
  isLoading,
  isEnhancing,
  isTransparent,
  setIsTransparent,
  aspectRatio,
  setAspectRatio,
}) => {
  const aspectRatios = [
    { value: '1:1', label: 'Square', icon: 'aspect-square' as const },
    { value: '16:9', label: 'Landscape', icon: 'aspect-landscape' as const },
    { value: '9:16', label: 'Portrait', icon: 'aspect-portrait' as const },
  ];

  return (
    <div className="flex flex-col h-full space-y-6">
      <div>
        <label htmlFor="prompt" className="block text-sm font-medium text-banana-yellow mb-2">
          Your Creative Prompt
        </label>
        <textarea
          id="prompt"
          rows={4}
          className="w-full bg-banana-dark border border-banana-surface rounded-lg p-3 focus:ring-2 focus:ring-banana-yellow focus:border-banana-yellow transition-all duration-200 resize-y"
          placeholder="e.g., An astronaut riding a dolphin..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
      </div>

      <div>
        <h3 className="text-sm font-medium text-banana-yellow mb-2">Style Boosts ✨</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {stylePresets.map((style) => (
            <StylePresetButton key={style.name} style={style} onClick={() => onStyleSelect(style)} />
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-banana-yellow mb-2">Aspect Ratio</h3>
        <div className="flex space-x-2">
          {aspectRatios.map((ratio) => {
            const isActive = aspectRatio === ratio.value;
            return (
              <button
                key={ratio.value}
                onClick={() => setAspectRatio(ratio.value)}
                title={ratio.label}
                className={`flex-1 flex flex-col items-center justify-center p-2 rounded-lg border-2 transition-colors duration-200 ${
                  isActive
                    ? 'bg-banana-yellow/10 border-banana-yellow text-banana-yellow'
                    : 'bg-banana-dark border-banana-surface hover:border-banana-surface/50 text-banana-light/70'
                }`}
              >
                <Icon type={ratio.icon} className="h-6 w-6 mb-1" />
                <span className="text-xs font-semibold">{ratio.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-banana-yellow mb-2">Options</h3>
        <label className="flex items-center space-x-3 cursor-pointer p-2 rounded-lg hover:bg-banana-dark transition-colors">
          <input
            type="checkbox"
            className="h-5 w-5 rounded bg-banana-dark border-banana-surface text-banana-yellow focus:ring-banana-yellow"
            checked={isTransparent}
            onChange={(e) => setIsTransparent(e.target.checked)}
          />
          <span className="text-banana-light">Transparent Background</span>
        </label>
      </div>

      <div className="space-y-3 pt-4 border-t border-banana-dark">
         <button
          onClick={onEnhance}
          disabled={isEnhancing || isLoading}
          className="w-full flex items-center justify-center space-x-2 bg-transparent border-2 border-banana-yellow/50 text-banana-yellow/80 font-semibold py-3 px-4 rounded-lg hover:bg-banana-yellow/10 hover:border-banana-yellow hover:text-banana-yellow transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isEnhancing ? (
            <>
              <Icon type="sparkles" className="animate-pulse-fast"/>
              <span>Enhancing...</span>
            </>
          ) : (
             <>
              <Icon type="sparkles" />
              <span>Enhance Prompt</span>
            </>
          )}
        </button>
        <button
          onClick={onGenerate}
          disabled={isLoading || isEnhancing}
          className="w-full flex items-center justify-center space-x-2 bg-banana-yellow text-banana-dark font-bold py-3 px-4 rounded-lg hover:bg-yellow-300 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Icon type="loader" className="animate-spin" />
              <span>Generating...</span>
            </>
          ) : (
            <>
              <Icon type="image" />
              <span>Generate Image</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
