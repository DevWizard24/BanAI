
import React from 'react';
import { GalleryItem as GalleryItemType } from '../types';
import { GalleryItem } from './GalleryItem';

interface GalleryViewProps {
  items: GalleryItemType[];
  onRemix: (prompt: string) => void;
}

export const GalleryView: React.FC<GalleryViewProps> = ({ items, onRemix }) => {
  return (
    <div className="container mx-auto p-4">
      <h2 className="text-3xl font-bold text-banana-yellow mb-6 text-center">Community Gallery</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {items.map(item => (
          <GalleryItem key={item.id} item={item} onRemix={onRemix} />
        ))}
      </div>
    </div>
  );
};
