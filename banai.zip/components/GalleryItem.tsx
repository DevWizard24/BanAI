
import React from 'react';
import { GalleryItem as GalleryItemType } from '../types';
import { Icon } from './Icon';

interface GalleryItemProps {
  item: GalleryItemType;
  onRemix: (prompt: string) => void;
}

export const GalleryItem: React.FC<GalleryItemProps> = ({ item, onRemix }) => {
  return (
    <div className="group relative aspect-square bg-banana-surface rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105">
      <img src={item.imageUrl} alt={item.prompt} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
        <p className="text-white text-sm font-medium line-clamp-3 mb-2">{item.prompt}</p>
        <button 
          onClick={() => onRemix(item.prompt)}
          className="self-start flex items-center space-x-2 bg-banana-yellow text-banana-dark font-bold py-2 px-3 rounded-md text-sm hover:bg-yellow-300 transition-all"
        >
          <Icon type="remix" className="h-4 w-4" />
          <span>Remix</span>
        </button>
      </div>
    </div>
  );
};
