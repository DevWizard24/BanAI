
export interface StylePreset {
  name: string;
  prompt: string;
  emoji: string;
}

export interface GalleryItem {
  id: string;
  prompt: string;
  imageUrl: string;
}
