
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { PromptControls } from './components/PromptControls';
import { ImageDisplay } from './components/ImageDisplay';
import { generateImage, enhancePrompt, upscaleImage } from './services/geminiService';
import { StylePreset, GalleryItem } from './types';
import { STYLE_PRESETS, MOCK_GALLERY_ITEMS } from './constants';
import { GalleryView } from './components/GalleryView';
import { DocsModal } from './components/DocsModal';

const initialItem: GalleryItem = {
  id: 'initial',
  prompt: 'A cute banana character, cartoon style',
  imageUrl: 'https://picsum.photos/seed/nanobanana/1024/1024'
};

export default function App() {
  const [view, setView] = useState<'studio' | 'gallery'>('studio');
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(MOCK_GALLERY_ITEMS);
  const [isDocsModalOpen, setIsDocsModalOpen] = useState<boolean>(false);

  const [history, setHistory] = useState<GalleryItem[]>([initialItem]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const [prompt, setPrompt] = useState<string>(initialItem.prompt);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);
  const [isUpscaling, setIsUpscaling] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isTransparent, setIsTransparent] = useState<boolean>(false);
  const [aspectRatio, setAspectRatio] = useState<string>('1:1');
  
  const currentItem = history[historyIndex];
  const imageUrl = currentItem?.imageUrl;

  // Load prompt from localStorage on initial render
  useEffect(() => {
    const savedPrompt = localStorage.getItem('banai_prompt');
    if (savedPrompt) {
      setPrompt(savedPrompt);
      // Sync the initial history item with the saved prompt
      setHistory(prev => {
        const updatedHistory = [...prev];
        if (updatedHistory.length > 0) {
          updatedHistory[0] = { ...updatedHistory[0], prompt: savedPrompt };
        }
        return updatedHistory;
      });
    }
  }, []); // Run only on mount

  // Save prompt to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('banai_prompt', prompt);
  }, [prompt]);

  useEffect(() => {
    const currentItem = history[historyIndex];
    if (currentItem && currentItem.prompt !== prompt) {
        setPrompt(currentItem.prompt);
    }
  }, [history, historyIndex]);

  const handleStyleSelect = useCallback((style: StylePreset) => {
    setPrompt(prev => `${prev}, ${style.prompt}`);
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!prompt || isLoading || isUpscaling) return;
    setIsLoading(true);
    setError(null);
    
    try {
      let finalPrompt = prompt;
      if (isTransparent) {
        finalPrompt += ', with a transparent background';
      }
      const generatedImageUrl = await generateImage(finalPrompt, aspectRatio);
      
      const newItem: GalleryItem = {
        id: new Date().toISOString(),
        prompt: finalPrompt,
        imageUrl: generatedImageUrl,
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, newItem]);
      setHistoryIndex(newHistory.length);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred while generating the image.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, isLoading, isUpscaling, isTransparent, aspectRatio, history, historyIndex]);

  const handleEnhance = useCallback(async () => {
    if (!prompt || isEnhancing || isUpscaling) return;
    setIsEnhancing(true);
    setError(null);
    try {
      const enhancedPrompt = await enhancePrompt(prompt);
      setPrompt(enhancedPrompt);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred while enhancing the prompt.');
    } finally {
      setIsEnhancing(false);
    }
  }, [prompt, isEnhancing, isUpscaling]);

  const handleUpscale = useCallback(async () => {
    const currentPrompt = history[historyIndex]?.prompt;
    if (!currentPrompt || !imageUrl || isUpscaling || isLoading) return;
    setIsUpscaling(true);
    setError(null);
    try {
      const upscaledImageUrl = await upscaleImage(currentPrompt, aspectRatio);
      
      const newItem: GalleryItem = {
        id: new Date().toISOString(),
        prompt: currentPrompt, // Use the prompt from the image being upscaled
        imageUrl: upscaledImageUrl,
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, newItem]);
      setHistoryIndex(newHistory.length);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred while upscaling the image.');
    } finally {
      setIsUpscaling(false);
    }
  }, [imageUrl, isUpscaling, isLoading, aspectRatio, history, historyIndex]);


  const handleNavigate = (newView: 'studio' | 'gallery') => {
    setView(newView);
  };

  const handleShareToGallery = (sharedPrompt: string, sharedImageUrl: string) => {
    const newItem: GalleryItem = {
      id: new Date().toISOString(), // simple unique id
      prompt: sharedPrompt,
      imageUrl: sharedImageUrl,
    };
    setGalleryItems(prevItems => [newItem, ...prevItems]);
    // A more sophisticated app would use a toast notification library
    alert("Image shared to gallery!");
  };

  const handleRemix = (remixPrompt: string) => {
    setPrompt(remixPrompt);
    setView('studio');
  };
  
  const handleHistory = (direction: 'back' | 'forward') => {
    if (direction === 'back' && historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
    }
    if (direction === 'forward' && historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
    }
  };

  const renderStudio = () => (
    <main className="flex-grow container mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      <div className="lg:col-span-4 xl:col-span-3 bg-banana-surface rounded-2xl shadow-lg p-6 space-y-6 sticky top-24">
        <PromptControls
          prompt={prompt}
          setPrompt={setPrompt}
          stylePresets={STYLE_PRESETS}
          onStyleSelect={handleStyleSelect}
          onGenerate={handleGenerate}
          onEnhance={handleEnhance}
          isLoading={isLoading || isUpscaling}
          isEnhancing={isEnhancing}
          isTransparent={isTransparent}
          setIsTransparent={setIsTransparent}
          aspectRatio={aspectRatio}
          setAspectRatio={setAspectRatio}
        />
      </div>
      <div className="lg:col-span-8 xl:col-span-9 h-full">
        <ImageDisplay
          imageUrl={imageUrl}
          isLoading={isLoading}
          isUpscaling={isUpscaling}
          error={error}
          prompt={currentItem?.prompt ?? ''}
          onShare={handleShareToGallery}
          onUpscale={handleUpscale}
          onHistoryBack={() => handleHistory('back')}
          onHistoryForward={() => handleHistory('forward')}
          canGoBack={historyIndex > 0}
          canGoForward={historyIndex < history.length - 1}
        />
      </div>
    </main>
  );

  return (
    <div className="min-h-screen bg-banana-bg font-sans flex flex-col">
      <Header 
        currentView={view} 
        onNavigate={handleNavigate}
        onOpenDocs={() => setIsDocsModalOpen(true)}
      />
      {view === 'studio' ? renderStudio() : <GalleryView items={galleryItems} onRemix={handleRemix} />}
      <DocsModal isOpen={isDocsModalOpen} onClose={() => setIsDocsModalOpen(false)} />
    </div>
  );
}
