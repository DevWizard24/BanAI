
import { GoogleGenAI, Modality } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateImage(prompt: string, aspectRatio: string): Promise<string> {
  try {
    let finalPrompt = prompt;
    if (aspectRatio !== '1:1') {
      finalPrompt = `${prompt}, ${aspectRatio} aspect ratio`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: finalPrompt }],
      },
      // FIX: Removed `numberOfImages` as it is not a supported config for the `gemini-2.5-flash-image` model.
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) {
        const base64ImageBytes: string = part.inlineData.data;
        return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
      }
    }
    throw new Error("No image data found in the response.");
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error("Failed to generate image. Please check the prompt or try again later.");
  }
}

export async function upscaleImage(prompt: string, aspectRatio: string): Promise<string> {
    try {
    let upscalePrompt = `${prompt}, HD, high resolution, 4k, ultra detailed`;
    if (aspectRatio !== '1:1') {
      upscalePrompt = `${upscalePrompt}, ${aspectRatio} aspect ratio`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: upscalePrompt }],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) {
        const base64ImageBytes: string = part.inlineData.data;
        return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
      }
    }
    throw new Error("No image data found in the upscale response.");
  } catch (error) {
    console.error("Error upscaling image:", error);
    throw new Error("Failed to upscale image. Please try again later.");
  }
}


export async function enhancePrompt(prompt: string): Promise<string> {
  try {
    const systemInstruction = `You are a creative assistant that enhances user prompts for an AI image generator. 
    Your goal is to make the prompt more descriptive, vivid, and specific to generate better images. 
    Rewrite the user's prompt to be more imaginative.
    Return ONLY the new prompt, without any introductions, explanations, or quotation marks.`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Original prompt: "${prompt}"`,
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.8,
        }
    });

    let enhancedPrompt = response.text.trim();
    // Clean up potential markdown or quotes
    if (enhancedPrompt.startsWith('"') && enhancedPrompt.endsWith('"')) {
        enhancedPrompt = enhancedPrompt.substring(1, enhancedPrompt.length - 1);
    }

    return enhancedPrompt;
  } catch (error) {
    console.error("Error enhancing prompt:", error);
    throw new Error("Failed to enhance prompt. Please try again later.");
  }
}
